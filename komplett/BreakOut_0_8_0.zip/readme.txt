﻿Steuerung:
Schläger bewegen:	Maus oder Pfeiltasten <- und -> (je nach gewählter Steuerung)
Ball starten:		Leertaste
Spiel neu starten:	R
Spiel pausieren:	P
