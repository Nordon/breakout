Steuerung:
Schläger bewegen:	Pfeiltasten <- und ->
Ball starten:		Leertaste
Spiel neu starten:	R
Spiel pausieren:	P
