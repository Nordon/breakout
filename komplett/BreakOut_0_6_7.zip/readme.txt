﻿Steuerung:
Schläger bewegen:	Maus
Ball starten:		Leertaste
Spiel neu starten:	R
Spiel pausieren:	P
